open module appname {
        requires javafx.controls;
        requires javafx.media;
}