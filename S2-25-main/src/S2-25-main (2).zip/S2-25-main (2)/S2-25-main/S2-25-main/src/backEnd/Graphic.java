package backEnd;

public class Graphic {
    public Graphic()
    {

    }
    public void ShowGraphics()
    {
    }


}
