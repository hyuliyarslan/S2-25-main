package backEnd;

public enum Colors {
    RED,BLUE,YELLOW,GREEN,PURPLE,ORANGE,NONE
}
