package appname.model;

/**
 * The model consists of multiple classes referring to the domain concepts
 * This class represents the main business concept handled in a scene
 * It may have attributes referring to other concepts
 */
public class ModelName {

	// private attributes

	public ModelName() {
		// Constructor
	}

	// methods with business logic

	// needed getters and setters

}
