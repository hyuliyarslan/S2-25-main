package appname.view.about;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class HelpView extends BorderPane {


    public HelpView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {


    }

    private void layoutNodes() {


        setStyle("-fx-background-color: lightBlue");


    }


}
