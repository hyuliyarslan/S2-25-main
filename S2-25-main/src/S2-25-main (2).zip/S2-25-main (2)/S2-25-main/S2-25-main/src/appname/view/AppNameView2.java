package appname.view;

import javafx.scene.layout.BorderPane;

public class AppNameView2 extends BorderPane {
	// private Node attributes (controls)

	public AppNameView2() {
		initialiseNodes();
		layoutNodes();
	}

	private void initialiseNodes() {
		// TODO create and configure controls
		// button = new Button("...")
		// label = new Label("...")
	}

	private void layoutNodes() {

		// add/set … methodes
		// Insets, padding, alignment, …
	}

	// package-private Getters
	// for controls used by Presenter

}
