package appname.model;

public class Client {
    public static void main(String[] args) {
       Game game = new Game();
       game.playGame();

    }//main
}//class