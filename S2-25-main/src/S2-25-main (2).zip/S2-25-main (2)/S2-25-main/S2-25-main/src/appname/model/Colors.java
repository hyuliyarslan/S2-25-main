package appname.model;

public enum Colors {
    RED,BLUE,YELLOW,GREEN,PURPLE,ORANGE
}
