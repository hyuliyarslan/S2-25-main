package appname.model;

import java.util.List;

public class Player {
    private String name;
    private boolean win;
    private boolean connected;
    public Player(String name, boolean win) {
        this.name = name;
        this.win = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isWin() {
        return win;
    }

    public void setWin(boolean win) {
        this.win = win;
    }


    public Player() {
    }

    public void placeTile() {
        System.out.println("Place the backEnd.Tile");
    }

    public void removeTile() {
        System.out.println("Remove the backEnd.Tile");
    }

    public void selectTile(){
        System.out.println("Select a tile");}


}//class
