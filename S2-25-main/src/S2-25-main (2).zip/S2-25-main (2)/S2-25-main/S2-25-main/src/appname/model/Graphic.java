package appname.model;

public class Graphic {
    public Graphic()
    {

    }
    public void ShowGraphics()
    {
    }


}
