package appname.model;

public class Board {
    private final int  max_rows = 11;
    private final int max_columns = 11;
    final private boolean finished = true;
    private String board[][] = new String[max_rows][max_columns];
    private int counter = 0;
    private String color;
    private int amountToWin = 0;
    private Player player = new Player();

    public void createBoard()
    {
        //moveTile();

        for (int y = 0; y <= 5;y++)
        {
            for (int x = 0; x <= 5+y;x++)
            {
                board[y][x] = "none";
            }
        }

        for (int y = 6; y <= 10;y++)
        {
            for (int x = 0; x <= 9 - counter;x++)
            {
                board[y][x] = "none";

            }
            counter++;
        }
    }


    public void checkTiles()
    {

    }
    public void connected() {
        //Get position of each tile
        for (int colors = 0; colors <= 5; colors++) {
            switch (colors) {
                case 0:
                    color = "red";
                    break;
                case 1:
                    color = "blue";
                    break;
                case 2:
                    color = "green";
                    break;
                case 3:
                    color = "purple";
                    break;
                case 4:
                    color = "yellow";
                    break;
                case 5:
                    color = "orange";
                    break;
            }

            for (int y = 0; y <= max_rows - 1; y++) {
                for (int x = 0; x <= max_columns - 1; x++) {
                    if (board[y][x].equalsIgnoreCase(color)) {
                        for (int a = 0; a <= 5; a++) {
                            for (int b = 0; b <= 5; b++) {
                            }
                        }

                    }
                }
            }
        }
    }

//        public void moveTile()
//        {
//            player.move();
//        }



    }

//class
